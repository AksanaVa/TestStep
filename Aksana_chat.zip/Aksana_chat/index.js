var express = require('express');
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use(express.static('public'));

console.log('0')
console.log('Подключили библиотеки')

app.get('/', function (req, res) {
  console.log('2')
  res.sendFile('index.html', {
    root: './public'
  });
  console.log('Request/');

});

let arr=[];

app.post('/messages', function (req, res) {
  const message = {
    user: req.body.user,
    text: req.body.text
  }
  arr.push(message);

  res.json(JSON.stringify(arr));
  console.log('6')
  console.log('post-message:', arr)
});

app.get('/messages', function (req, res) {
  console.log('7')
  console.log('get-message:', arr)
  res.send(arr);
  
});

app.listen(8080, function () {
  console.log('1')
  console.log("Слушаем порт 8080")

});