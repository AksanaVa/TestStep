const alert = document.querySelector('.alert');
alert.style.display = "none";
const loader = document.querySelector('.loader');
loader.style.display = "none";

const btn = document.querySelector('.btn');
/*btn.addEventListener('click', () => { loader.style.display = "block"; })*/

const form = document.forms[0];
form.addEventListener('submit', (e) => {

	e.preventDefault();
	console.log('3')
	console.log('Зашли в обработчик отправки формы на фронтэнде')
	bootbox.confirm({
		message: "Подтвердить отправку данных?",
		buttons: {
			confirm: {
				label: 'Yes',
				className: 'btn-success'
			},
			cancel: {
				label: 'No',
				className: 'btn-danger'
			}
		},
		callback: function (result) {
			console.log('This was logged in the callback: ' + result);

			if (result) {
				console.log('3.1')
				loader.style.display = "block";
				fetch("http://localhost:8080/messages")
					.then(response => {
						response.json();
						console.log('3.2 response:', response)
					})
					.then(data => {
						console.log('3.3 Данные на вывод', data);
						const div = document.body.querySelector('div.output');
						div.innerHTML = JSON.stringify(data);
					})

				const data = {};

				// отправка

				function postData(url, data) {
					console.log('4')
					//const text = document.querySelector(".user");
					data.text = form.elements[1].value;
					data.user = form.elements[0].value;
					// Default options are marked with *
					const response = fetch(url, {
						method: 'POST',
						mode: 'cors',
						headers: {
							'Content-Type': 'application/json'
							// 'Content-Type': 'application/x-www-form-urlencoded',
						},
						body: JSON.stringify(data)
					});
					return response;
				}

				postData('http://localhost:8080/messages', data)
					.then((data) => {
						console.log('5: ', data);
						loader.style.display = "none";
						alert.style.display = "block";

					});
			}
		}
	});

});