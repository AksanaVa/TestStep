<template>
<div>
  <Post></Post>
  <h1>Выводится страница SinglePost. И пост номер {{$route.params.postId}}</h1>
</div>
</template>

<script>
import Post from '@/components/Post.vue';

export default {
  name: 'SinglePost',
  components: Post,
};
</script>
