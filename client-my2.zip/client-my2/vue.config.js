const WebpackNotifierPlugin = require('webpack-notifier');

module.exports = {
  configureWebpack: {
    plugins: [
      new WebpackNotifierPlugin(),
    ],
  },
};
