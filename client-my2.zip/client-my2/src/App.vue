<template>
  <div id="app">

    <Nav>
      <li class="nav-item">
        <router-link class="nav-link" to="/">Home</router-link> |
      </li>
      <li class="nav-item">
        <router-link class="nav-link" to="/about">About</router-link> |
      </li>
      <li class="nav-item">
        <router-link class="nav-link" to="/test">Test</router-link> |
      </li>
    </Nav>
    <div class="container">
      <main>
        <router-view/>
      </main>
      <SideBar></SideBar>
    </div>
  </div>
</template>
<script>
import Nav from './components/Nav.vue';
import SideBar from './components/SideBar.vue';

export default {
  components: {
    Nav,
    SideBar,
  },
};
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;

}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}


.container{
  display:flex;
  justify-content: space-between;
}
.home{
    display: flex;
    flex-wrap: wrap;
  }
.card{
    margin: 10px;
}
</style>
