<template>
  <div class="home">
    <PostCard class="posts" v-for = "post in posts"
    v-bind:post="post" v-bind:key="post.id"></PostCard>
  </div>
</template>

<script>
import axios from 'axios';
import PostCard from '@/components/PostCard.vue';


export default {
  name: 'Home',
  data: function () {
    return {
      posts: [],
    };
  },
  components: {
    PostCard,
  },
  mounted: function () {
    axios.get('http://localhost:3000/posts?offset=0&limit=9')
      .then((response) => {
        console.log('response', response.data);
        this.posts = response.data;
        console.log('response-arr', this.posts);
      });
  },
};
</script>
