<template>
  <div class="test">
    <h1>This is a test page</h1>
  </div>
</template>
