<template>
  <div class="card" style="width: 18rem;">
    <img :src="'https://picsum.photos/seed/'+ post.id + '/200/300'" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">{{post.title}}</h5>
      <p class="card-text">{{post.author}} - {{post.date | humanDate}}</p>
      <router-link class="btn btn-primary" :to="{ name: 'Post', params: { postId: post.id }}">
        Смотреть подробнее
      </router-link>
    </div>
  </div>
</template>

<script>
import moment from 'moment';

export default {
  name: 'PostCard',
  props: ['post'],
  filters: {
    humanDate: function (value) {
      moment.updateLocale('ru', {
        relativeTime: {
          future: 'in %s',
          past: '%s назад',
          s: 'hello, a few seconds',
          ss: '%d seconds',
          m: 'a minute',
          mm: '%d minutes',
          h: 'an hour',
          hh: '%d hours',
          d: 'a day',
          dd: '%d days',
          M: 'a месяц',
          MM: '%d месяца',
          y: 'a year',
          yy: '%d лет',
        },
      });
      const date = moment(value);
      return date.fromNow();
    },
  },
};
</script>
