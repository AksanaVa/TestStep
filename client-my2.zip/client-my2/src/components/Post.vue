<template>
  <h1>Выводится компонент Post. И пост номер {{$route.params.postId}}</h1>
</template>

<script>
export default {
  name: 'Post',
};
</script>
